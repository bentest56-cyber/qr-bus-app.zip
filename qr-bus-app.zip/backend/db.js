import sqlite3 from 'sqlite3';
import { open } from 'sqlite';
export async function initDB(file) {
  const db = await open({ filename: file, driver: sqlite3.Database });
  await db.exec(`CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    class TEXT
  );
  CREATE TABLE IF NOT EXISTS presence (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER,
    timestamp TEXT DEFAULT CURRENT_TIMESTAMP
  );`);
  return db;
}