import express from 'express';
import dotenv from 'dotenv';
import crypto from 'crypto';
import { initDB } from './db.js';
dotenv.config();
const app = express();
app.use(express.json());
const db = await initDB(process.env.DB_FILE);

function verifyHmac(payload, signature, secret) {
  const computed = crypto.createHmac('sha256', secret).update(JSON.stringify(payload)).digest('hex');
  return computed === signature;
}

app.get('/api/students', async (_, res) => {
  const rows = await db.all('SELECT * FROM students');
  res.json(rows);
});

app.post('/api/presence', async (req, res) => {
  const { id, name, signature } = req.body;
  if (!verifyHmac({ id, name }, signature, process.env.HMAC_SECRET))
    return res.status(401).json({ error: 'Signature invalide' });
  await db.run('INSERT INTO presence (student_id) VALUES (?)', [id]);
  res.json({ success: true });
});

app.listen(process.env.PORT, () => console.log(`Backend running on ${process.env.PORT}`));